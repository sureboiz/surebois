- 👋 Hi, I’m @sureboiz
- 👀 I’m interested in ...IT,Cybersecurity,music,art,lifestyle,luxury
- 🌱 I’m currently learning ...How to enjoy and live life while working
- 💞️ I’m looking to collaborate on ...Remote jobs,networking,hands on deck teaching and educational advancement 
- 📫 How to reach me ...Osemeikhianomon@gmail.com
- 😄 Pronouns: ...HE/HIM
- ⚡ Fun fact: ...small but MIGHTY 

<!---
sureboiz/sureboiz is a ✨ special ✨ repository because its `README.md` (this file) appears on your GitHub profile.
You can click the Preview link to take a look at your changes.
--->
